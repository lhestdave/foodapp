<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Food Cart</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table table-hover">
                    <thead class="thead">
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Food Name</th>
                        <th scope="col">Price (Php)</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Amount</th>
                      </tr>
                    </thead>
                      <tbody>
                        <?php $c = 0; $alltotal=0; $orderid = 0;?>
                        <?php if(count($foods) > 0): ?>
                          <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="tr<?php echo e($food->menuitemsid); ?>">
                              <?php $c++; $orderid = $food->orderid; ?>
                              <td><?php echo e($c); ?></td>
                              <td><?php echo e($food->foodname); ?></td>
                              <td><?php echo e($food->amount); ?></td>
                              <td><?php echo e($food->quantity); ?></td>
                              <td><?php echo e(number_format(($food->quantity * $food->amount),2)); ?></td>
                              <?php $alltotal= $alltotal + ($food->quantity * $food->amount); ?>
                              <td> <button type="button" name="delbutton" class="btn btn-danger" onclick="delItem('<?php echo e($orderid); ?>','<?php echo e($food->menuitemsid); ?>')">X</i></button> </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                          <td colspan="5">NO ITEMS ON THE CART</td>
                        </tr>
                        <?php endif; ?>
                      </tbody>
                    </table>
                    <form class="" action="<?php echo e(url('saveorder')); ?>" method="post">
                      <?php echo e(csrf_field()); ?>

                      <input type="text" name="txtorderid" id="txtorderid" value="<?php echo e($orderid); ?>" hidden>
                    <table class="table">
                      <tbody>
                        <tr>
                          <td width="80%">Subtotal (Php) <input type="text" name="txtstotal" id="txtstotal" value="<?php echo e($alltotal); ?>" hidden></td>
                          <td width="20%"><?php echo e(number_format($alltotal,2)); ?></td>
                        </tr>
                        <tr>
                          <td width="80%">Discount
                            <input type="text" name="txtdiscval" id="txtdiscval" value="0.00" hidden>
                            <input type="text" name="couponcode" id="couponcode" placeholder="coupon code">
                            <button type="button" name="button" onclick="getCoupon('<?php echo e($alltotal); ?>')"> Enter </button>
                            <p class="text-info" id="codemsgok" style="display:none"> Valid Code </p>
                            <p class="text-danger" id="codemsgerror" style="display:none"> Invalid Coupon </p>
                          </td>
                          <td width="20%" id="tddisc">0.00</td>

                        </tr>
                        <tr>
                          <td width="80%">Tax VAT 12% (Php)</td>
                          <td width="20%" id="taxdue"><?php echo e($alltotal * 0.12); ?></td>
                        </tr>
                        <tr>
                          <td width="80%">Total Due (Php)
                            <input type="text" name="txttotal" id="txttotal" value="<?php echo e($alltotal); ?>" hidden></td>
                          <td width="20%" id="tddue"><?php echo e($alltotal); ?></td>
                        </tr>
                      </tbody>
                    </table>
                    <button type="submit" name="button">Check Out</button>

                  </form>
                </div>
            </div>
        </div>
        <hr>
    </div>
</div>
<?php $__env->stopSection(); ?>
<script type="text/javascript">
  function delItem(oid, mid)
  {
    var r = confirm("Are you sure that you want to delete?");
    if (r == true) {
      //txt = "You pressed OK!";
      $.ajaxSetup({
      headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax({
            type: 'POST',
            url: '/order/delItem',
            data: {
                '_token': $('input[name=_token]').val(),
                'menuid':mid,
                'orderid':oid
            },
            success: function(data){
                // console.log(data);
                //alert("Item has been deleted to your cart.");
                $("tr#tr"+mid).remove();
                setTimeout("location.reload(true);",1000);
            },
            error:function(data)
            {
               //console.log(data);
               alert(data);
            }
        });
      }
  }
  function getCoupon(stotal)
  {
    code = document.getElementById('couponcode').value;
    $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
          type: 'POST',
          url: '/coupon/get',
          data: {
              '_token': $('input[name=_token]').val(),
              'code':code,
          },
          success: function(data){
              console.log(data);
              var disc = 0;
              if(data.length > 0){

                for (var i = 0; i < data.length; i++) {
                      disc=data[i].discount;
                }
                alert("Coupon Discount "+disc+"%");
                //document.getElementById('discval').value = disc.toString();
                document.getElementById('txtdiscval').value = (stotal * (disc/100)).toFixed(2).toString();
                document.getElementById('txttotal').value = (stotal - (stotal * (disc/100))).toFixed(2).toString();
                // document.getElementById('tddisc').firstChild.data = (stotal * (disc/100)).toString();
                // var tddisc = document.getElementById('tddisc');
                // var text = document.createTextNode((stotal * (disc/100)).toString());
                // tddisc.textContent(text);
                tddisc.textContent  = (stotal * (disc/100)).toFixed(2).toString();
                //
                // var tddue = document.getElementById('tddue');
                // var text2 = document.createTextNode(stotal - (stotal * (disc/100)).toString());
                // tddue.textContent(text2);
                tddue.textContent = (stotal - (stotal * (disc/100))).toFixed(2).toString();
                //
                // var taxdue = document.getElementById('taxdue');
                // var text3 = document.createTextNode(((stotal - (stotal * (disc/100)))*0.12).toString());
                taxdue.textContent = ((stotal - (stotal * (disc/100))) * 0.12).toFixed(2).toString();
              }else{
                //document.getElementById('discval').value = disc.toString();
                document.getElementById('txtdiscval').value = (stotal * (disc/100)).toFixed(2).toString();
                document.getElementById('txttotal').value = (stotal - (stotal * (disc/100))).toFixed(2).toString();
                // document.getElementById('tddisc').firstChild.data = (stotal * (disc/100)).toString();
                // var tddisc = document.getElementById('tddisc');
                // var text = document.createTextNode((stotal * (disc/100)).toString());
                // tddisc.textContent(text);
                tddisc.textContent  = (stotal * (disc/100)).toFixed(2).toString();
                //
                // var tddue = document.getElementById('tddue');
                // var text2 = document.createTextNode(stotal - (stotal * (disc/100)).toString());
                // tddue.textContent(text2);
                tddue.textContent = (stotal - (stotal * (disc/100))).toFixed(2).toString();
                //
                // var taxdue = document.getElementById('taxdue');
                // var text3 = document.createTextNode(((stotal - (stotal * (disc/100)))*0.12).toString());
                taxdue.textContent = ((stotal - (stotal * (disc/100))) * 0.12).toFixed(2).toString();
                alert('Invalid Coupon');
              }
          },
          error:function(data)
          {
             //console.log(data);
             alert('Error accessing to DB.');
          }
      });

  }
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\foodapp\resources\views/foodcart.blade.php ENDPATH**/ ?>