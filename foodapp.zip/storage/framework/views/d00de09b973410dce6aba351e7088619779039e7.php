<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Manage Orders</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table table-hover">
                    <thead class="thead">
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Order Date</th>
                        <th scope="col">Subtotal</th>
                        <th scope="col">Discount</th>
                        <th scope="col">Tax</th>
                        <th scope="col">Total Due</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                      <tbody>
                        <?php if($orders): ?>
                          <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($order->id); ?></td>
                              <td><?php echo e($order->created_at); ?></td>
                              <td><?php echo e($order->subtotal); ?></td>
                              <td><?php echo e($order->discount); ?></td>
                              <td><?php echo e(number_format(($order->total * 0.12), 2)); ?></td>
                              <td><?php echo e($order->total); ?></td>
                              <td> <a href="<?php echo e(url('order')); ?>/<?php echo e($order->id); ?>">View</a> </td>
                            </tr>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                      </tbody>
                    </table>

                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<script type="text/javascript">

</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\foodapp\resources\views/orders.blade.php ENDPATH**/ ?>