<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Food Cart</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table table-hover">
                    <thead class="thead">
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Food Name</th>
                        <th scope="col">Price (Php)</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Amount</th>
                      </tr>
                    </thead>
                      <tbody>
                        <?php $c = 0; $alltotal=0; $orderid = 0;?>
                        <?php if(count($foods) > 0): ?>
                          <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="tr<?php echo e($food->menuitemsid); ?>">
                              <?php $c++; $orderid = $food->orderid; ?>
                              <td><?php echo e($c); ?></td>
                              <td><?php echo e($food->foodname); ?></td>
                              <td><?php echo e($food->amount); ?></td>
                              <td><?php echo e($food->quantity); ?></td>
                              <td><?php echo e(number_format(($food->quantity * $food->amount),2)); ?></td>
                              <?php $alltotal= $alltotal + ($food->quantity * $food->amount); ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                          <td colspan="5">NO ITEMS ON THE CART</td>
                        </tr>
                        <?php endif; ?>
                      </tbody>
                    </table>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <table class="table">
                      <tbody>
                        <tr>
                          <td width="80%">Subtotal (Php)</td>
                          <td width="20%"><?php echo e(number_format($order->subtotal,2)); ?></td>
                        </tr>
                        <tr>
                          <td width="80%">Discount
                          </td>
                          <td width="20%" id="tddisc"><?php echo e(number_format($order->discount,2)); ?></td>

                        </tr>
                        <tr>
                          <td width="80%">Tax VAT 12% (Php)</td>
                          <td width="20%" id="taxdue"><?php echo e(number_format(($order->total *0.12), 2)); ?></td>
                        </tr>
                        <tr>
                          <td width="80%">Total Due (Php)
                          <td width="20%" id="tddue"><?php echo e(number_format($order->total,2)); ?></td>
                        </tr>
                      </tbody>
                    </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <hr>
    </div>
</div>
<?php $__env->stopSection(); ?>
<script type="text/javascript">

</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\foodapp\resources\views/orderdetails.blade.php ENDPATH**/ ?>