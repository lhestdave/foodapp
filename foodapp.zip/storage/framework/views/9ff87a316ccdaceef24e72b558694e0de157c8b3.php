<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <form class="" action="" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Burgers</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table table-hover">
                    <thead class="thead">
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Food Name</th>
                        <th scope="col">Price (Php)</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                      <tbody>
                      <?php if(count($burgers) > 0): ?>
                        <?php $__currentLoopData = $burgers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $br): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($br->id); ?></td>
                            <td><?php echo e($br->foodname); ?></td>
                            <td><?php echo e(number_format($br->amount,2)); ?></td>
                            <td> <input type="number" name="qty<?php echo e($br->id); ?>" id="qty<?php echo e($br->id); ?>" min="1" value="1"> </td>
                            <td> <button type="button" name="button" class="btn btn-primary" onclick="addToCart('<?php echo e($br->id); ?>','<?php echo e($br->amount); ?>')">Add to Cart</button> </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                      </tbody>
                    </table>

                </div>
            </div>
        </div>
        <br>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Beverages</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table table-hover">
                    <thead class="thead">
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Food Name</th>
                        <th scope="col">Price (Php)</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                      <tbody>
                      <?php if(count($bevs) > 0): ?>
                        <?php $__currentLoopData = $bevs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($bev->id); ?></td>
                            <td><?php echo e($bev->foodname); ?></td>
                            <td><?php echo e(number_format($bev->amount,2)); ?></td>
                            <td> <input type="number" name="qty<?php echo e($br->id); ?>" id="qty<?php echo e($bev->id); ?>" min="1" value="1"> </td>
                            <td> <button type="button" name="button" class="btn btn-primary" onclick="addToCart('<?php echo e($bev->id); ?>','<?php echo e($bev->amount); ?>')">Add to Cart</button> </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                      </tbody>
                    </table>
                </div>
            </div>
        </div>
        <br>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Combo Meals</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table table-hover">
                    <thead class="thead">
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Food Name</th>
                        <th scope="col">Price (Php)</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                      <tbody>
                      <?php if(count($cmeals) > 0): ?>
                        <?php $__currentLoopData = $cmeals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($cm->id); ?></td>
                            <td><?php echo e($cm->foodname); ?></td>
                            <td><?php echo e(number_format($cm->amount,2)); ?></td>
                            <td> <input type="number" name="qty<?php echo e($br->id); ?>" id="qty<?php echo e($cm->id); ?>" min="1" value="1"> </td>
                            <td> <button type="button" name="button" class="btn btn-primary" onclick="addToCart('<?php echo e($cm->id); ?>','<?php echo e($cm->amount); ?>')">Add to Cart</button> </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                      </tbody>
                    </table>
                </div>
            </div>
        </div>

      </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<script type="text/javascript">
  function addToCart(id, price)
  {
    qty = document.getElementById('qty'+id).value;
    if(qty > 0){

      $.ajaxSetup({
      headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax({
            type: 'POST',
            url: '/order/savemenu',
            data: {
                '_token': $('input[name=_token]').val(),
                'menuid':id,
                'qty':qty,
                'price':price
            },
            success: function(data){
                //console.log(data);
                alert("Item has been added to your cart.");
            },
            error:function(data)
            {
               //console.log(data);
               alert(data);
            }
        });



    }else{
      alert("Error Quantity");
    }

  }
  function getJoid(id)
  {
    var joid = id;
    $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
          type: 'POST',
          url: '/jo/gettask',
          data: {
              '_token': $('input[name=_token]').val(),
              'joid':joid,
          },
          success: function(data){
              //console.log(data);
              $("tr.trtask").remove();
              var markup = '';
              for (var i = 0; i < data.length; i++) {
                if(data[i].tsid == 6){
                  markup += '<tr class="trtask"><td >'+(i+1)+'</td><td>'+data[i].taskname+'</td><td >'+data[i].leadtime+'</td><td >'+data[i].amount+'</td><td>['+data[i].name+']:'+data[i].state+'<br>'+data[i].created_at+'</td><td>'+
                  '<button class="btn btn-outline-primary my-2 my-sm-0 btn-sm taskstatus" data-toggle="modal" data-target="#updateTaskModal" type="button" onclick="gettaskStatus('+data[i].tid+','+data[i].tsid+')" rel="tooltip" title="Update Status" disabled><span class="fas fa-edit"></span></button>'+
                  '</td></tr>';
                }else{
                  markup += '<tr class="trtask"><td >'+(i+1)+'</td><td>'+data[i].taskname+'</td><td >'+data[i].leadtime+'</td><td >'+data[i].amount+'</td><td>['+data[i].name+']:'+data[i].state+'<br>'+data[i].created_at+'</td><td>'+
                  '<button class="btn btn-outline-primary my-2 my-sm-0 btn-sm taskstatus" data-toggle="modal" data-target="#updateTaskModal" type="button" onclick="gettaskStatus('+data[i].tid+','+data[i].tsid+')" rel="tooltip" title="Update Status" ><span class="fas fa-edit"></span></button>'+
                  '</td></tr>';
                }
              }
              $("table tbody #tbody"+joid).append(markup);

          },
          error:function(data)
          {
             console.log(data);
          }
      });
  }
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\foodapp\resources\views/home.blade.php ENDPATH**/ ?>